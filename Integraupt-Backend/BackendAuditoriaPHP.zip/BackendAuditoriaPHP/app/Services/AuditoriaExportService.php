<?php

namespace App\Services;

use App\DTOs\AuditoriaReservaFiltro;
use App\DTOs\AuditoriaReservaResponse;
use App\Interfaces\IAuditoriaReservaServicio;
use Barryvdh\DomPDF\Facade\Pdf;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class AuditoriaExportService
{
    // Formato de fecha
    private const DATE_TIME_FORMAT = 'd/m/Y H:i';

    private IAuditoriaReservaServicio $auditoriaReservaServicio;

    public function __construct(IAuditoriaReservaServicio $auditoriaReservaServicio)
    {
        $this->auditoriaReservaServicio = $auditoriaReservaServicio;
    }

    // Generar reporte en PDF
    public function generarReportePdf(AuditoriaReservaFiltro $filtro): string
    {
        $registros = $this->auditoriaReservaServicio->buscar($filtro);

        $html = $this->construirHtmlPdf($registros);

        $pdf = Pdf::loadHTML($html);
        $pdf->setPaper('A4', 'landscape');

        return $pdf->output();
    }

    // Generar reporte en Excel
    public function generarReporteExcel(AuditoriaReservaFiltro $filtro): string
    {
        $registros = $this->auditoriaReservaServicio->buscar($filtro);

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Auditorias');

        // Encabezados
        $headers = ['# Audit', 'Reserva', 'Cambio', 'Usuario', 'Espacio', 'Fecha'];
        foreach ($headers as $col => $header) {
            $cell = $sheet->getCellByColumnAndRow($col + 1, 1);
            $cell->setValue($header);
            $cell->getStyle()->getFont()->setBold(true);
            $cell->getStyle()->getAlignment()->setWrapText(true);
        }

        // Datos
        $rowIndex = 2;
        foreach ($registros as $registro) {
            $sheet->setCellValueByColumnAndRow(1, $rowIndex, $registro->idAudit);
            $sheet->setCellValueByColumnAndRow(2, $rowIndex, $registro->idReserva);
            $sheet->setCellValueByColumnAndRow(3, $rowIndex, $registro->estadoAnterior . ' -> ' . $registro->estadoNuevo);
            $sheet->setCellValueByColumnAndRow(4, $rowIndex, $registro->usuarioCambioNombre ?? 'Sin usuario');
            $sheet->setCellValueByColumnAndRow(5, $rowIndex, $registro->nombreEspacio ?? 'Sin espacio');
            $sheet->setCellValueByColumnAndRow(6, $rowIndex, $this->formatFecha($registro->fechaCambio));
            $rowIndex++;
        }

        // Ajustar columnas
        foreach (range(1, 6) as $col) {
            $sheet->getColumnDimensionByColumn($col)->setAutoSize(true);
        }

        // Escribir archivo
        $writer = new Xlsx($spreadsheet);
        ob_start();
        $writer->save('php://output');
        $content = ob_get_clean();

        return $content;
    }

    // Construir HTML para el reporte PDF
    private function construirHtmlPdf(array $registros): string
    {
        $totalEventos = count($registros);

        $filas = '';
        foreach ($registros as $registro) {
            $cambio = htmlspecialchars($registro->estadoAnterior . ' -> ' . $registro->estadoNuevo);
            $usuario = htmlspecialchars($registro->usuarioCambioNombre ?? 'Sin usuario');
            $espacio = htmlspecialchars($registro->nombreEspacio ?? 'Sin espacio');
            $fecha = $this->formatFecha($registro->fechaCambio);

            $filas .= "
                <tr>
                    <td>{$registro->idAudit}</td>
                    <td>#{$registro->idReserva}</td>
                    <td>{$cambio}</td>
                    <td>{$usuario}</td>
                    <td>{$espacio}</td>
                    <td>{$fecha}</td>
                </tr>";
        }

        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body { font-family: Arial, sans-serif; font-size: 11px; }
                h1 { text-align: center; font-size: 14px; margin-bottom: 5px; }
                .subtitle { margin-bottom: 15px; font-size: 11px; }
                table { width: 100%; border-collapse: collapse; }
                th { background-color: #f2f2f2; font-weight: bold; text-align: center;
                     border: 1px solid #ccc; padding: 6px; }
                td { border: 1px solid #ccc; padding: 5px; text-align: left; }
                tr:nth-child(even) { background-color: #fafafa; }
            </style>
        </head>
        <body>
            <h1>Reporte de Auditoria de Reservas</h1>
            <p class='subtitle'>Total de eventos: {$totalEventos}</p>
            <table>
                <thead>
                    <tr>
                        <th># Audit</th>
                        <th>Reserva</th>
                        <th>Cambio</th>
                        <th>Usuario</th>
                        <th>Espacio</th>
                        <th>Fecha</th>
                    </tr>
                </thead>
                <tbody>
                    {$filas}
                </tbody>
            </table>
        </body>
        </html>";
    }

    // Formatear fecha
    private function formatFecha(?string $fecha): string
    {
        if ($fecha === null) {
            return '-';
        }

        try {
            $dateTime = new \DateTime($fecha);
            return $dateTime->format(self::DATE_TIME_FORMAT);
        } catch (\Exception $e) {
            return '-';
        }
    }
}
