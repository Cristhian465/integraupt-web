<?php

namespace App\Services;

use App\DTOs\AuditoriaReservaFiltro;
use App\DTOs\AuditoriaReservaResponse;
use App\Interfaces\IAuditoriaReservaServicio;
use App\Repositories\AuditoriaReservaRepository;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class AuditoriaReservaService implements IAuditoriaReservaServicio
{
    private AuditoriaReservaRepository $repository;

    public function __construct(AuditoriaReservaRepository $repository)
    {
        $this->repository = $repository;
    }

    // Buscar auditorías con filtros opcionales
    public function buscar(AuditoriaReservaFiltro $filtro): array
    {
        $estado = $filtro->getEstado();
        $registros = $this->repository->buscar(
            $filtro->reservaId,
            $estado ? strtoupper($estado) : null,
            $filtro->getTerminoUsuario(),
            $filtro->fechaInicio,
            $filtro->fechaFin
        );

        return $this->mapearLista($registros);
    }

    // Listar auditorías por ID de reserva
    public function listarPorReserva(int $reservaId): array
    {
        $registros = $this->repository->listarPorReserva($reservaId);
        return $this->mapearLista($registros);
    }

    // Buscar una auditoría por su ID
    public function buscarPorId(int $idAudit): AuditoriaReservaResponse
    {
        $registro = $this->repository->obtenerDetalle($idAudit);

        if ($registro === null) {
            throw new NotFoundHttpException('Auditoria no encontrada');
        }

        return $this->mapear($registro);
    }

    // Mapear lista de registros a DTOs
    private function mapearLista(array $registros): array
    {
        return array_values(
            array_map(
                fn(array $row) => $this->mapear($row),
                array_filter($registros, fn($row) => $row !== null)
            )
        );
    }

    // Mapear un registro individual a DTO
    private function mapear(array $row): AuditoriaReservaResponse
    {
        return new AuditoriaReservaResponse(
            idAudit: isset($row['idAudit']) ? (int) $row['idAudit'] : null,
            idReserva: isset($row['idReserva']) ? (int) $row['idReserva'] : null,
            estadoAnterior: $row['estadoAnterior'] ?? null,
            estadoNuevo: $row['estadoNuevo'] ?? null,
            fechaCambio: $row['fechaCambio'] ?? null,
            usuarioCambioId: isset($row['usuarioCambioId']) ? (int) $row['usuarioCambioId'] : null,
            usuarioCambioNombre: $this->normalizarNombre($row['usuarioCambioNombre'] ?? null),
            usuarioCambioDocumento: $row['usuarioCambioDocumento'] ?? null,
            estadoReservaActual: $row['estadoReservaActual'] ?? null,
            descripcionUso: $row['descripcionUso'] ?? null,
            fechaReserva: $row['fechaReserva'] ?? null,
            codigoEspacio: $row['codigoEspacio'] ?? null,
            nombreEspacio: $row['nombreEspacio'] ?? null,
        );
    }

    // Normalizar nombre eliminando espacios dobles
    private function normalizarNombre(?string $nombre): ?string
    {
        if ($nombre === null) {
            return null;
        }
        return preg_replace('/\s{2,}/', ' ', trim($nombre));
    }
}
