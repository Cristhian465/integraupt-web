<?php

namespace App\Repositories;

use Illuminate\Support\Facades\DB;

class AuditoriaReservaRepository
{
    // Query base para las consultas de auditoría
    private function queryBase(): string
    {
        return "
            SELECT
                a.IdAudit AS idAudit,
                a.IdReserva AS idReserva,
                a.EstadoAnterior AS estadoAnterior,
                a.EstadoNuevo AS estadoNuevo,
                a.FechaCambio AS fechaCambio,
                a.UsuarioCambio AS usuarioCambioId,
                CONCAT(
                    COALESCE(u.Nombre, ''),
                    CASE WHEN u.Nombre IS NOT NULL AND u.Apellido IS NOT NULL THEN ' ' ELSE '' END,
                    COALESCE(u.Apellido, '')
                ) AS usuarioCambioNombre,
                u.NumDoc AS usuarioCambioDocumento,
                r.Estado AS estadoReservaActual,
                r.DescripcionUso AS descripcionUso,
                r.fechaReserva AS fechaReserva,
                e.Codigo AS codigoEspacio,
                e.Nombre AS nombreEspacio
            FROM auditoriareserva a
            JOIN reserva r ON r.IdReserva = a.IdReserva
            LEFT JOIN usuario u ON u.IdUsuario = a.UsuarioCambio
            LEFT JOIN espacio e ON e.IdEspacio = r.espacio
        ";
    }

    // Buscar resúmenes con filtros opcionales
    public function buscar(
        ?int $reservaId = null,
        ?string $estado = null,
        ?string $usuarioTerm = null,
        ?string $fechaInicio = null,
        ?string $fechaFin = null
    ): array {
        $sql = $this->queryBase() . "
            WHERE (:reservaId IS NULL OR a.IdReserva = :reservaId)
              AND (
                :estado IS NULL
                OR UPPER(a.EstadoNuevo) = UPPER(:estado)
                OR UPPER(a.EstadoAnterior) = UPPER(:estado)
              )
              AND (
                :usuarioTerm IS NULL
                OR u.Nombre LIKE CONCAT('%', :usuarioTerm2, '%')
                OR u.Apellido LIKE CONCAT('%', :usuarioTerm3, '%')
                OR u.NumDoc LIKE CONCAT('%', :usuarioTerm4, '%')
              )
              AND (:fechaInicio IS NULL OR a.FechaCambio >= :fechaInicio)
              AND (:fechaFin IS NULL OR a.FechaCambio <= :fechaFin)
            ORDER BY a.FechaCambio DESC
        ";

        $results = DB::select($sql, [
            'reservaId' => $reservaId,
            'estado' => $estado ? strtoupper($estado) : null,
            'usuarioTerm' => $usuarioTerm,
            'usuarioTerm2' => $usuarioTerm,
            'usuarioTerm3' => $usuarioTerm,
            'usuarioTerm4' => $usuarioTerm,
            'fechaInicio' => $fechaInicio,
            'fechaFin' => $fechaFin,
        ]);

        return array_map(fn($row) => (array) $row, $results);
    }

    // Listar auditorías por ID de reserva
    public function listarPorReserva(int $reservaId): array
    {
        $sql = $this->queryBase() . "
            WHERE a.IdReserva = :reservaId
            ORDER BY a.FechaCambio DESC
        ";

        $results = DB::select($sql, ['reservaId' => $reservaId]);

        return array_map(fn($row) => (array) $row, $results);
    }

    // Obtener detalle de una auditoría por su ID
    public function obtenerDetalle(int $idAudit): ?array
    {
        $sql = $this->queryBase() . "
            WHERE a.IdAudit = :idAudit
        ";

        $results = DB::select($sql, ['idAudit' => $idAudit]);

        if (empty($results)) {
            return null;
        }

        return (array) $results[0];
    }
}
