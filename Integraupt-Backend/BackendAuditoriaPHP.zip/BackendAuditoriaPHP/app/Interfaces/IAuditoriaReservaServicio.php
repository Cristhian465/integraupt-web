<?php

namespace App\Interfaces;

use App\DTOs\AuditoriaReservaFiltro;
use App\DTOs\AuditoriaReservaResponse;

interface IAuditoriaReservaServicio
{
    // Buscar auditorías con filtros
    public function buscar(AuditoriaReservaFiltro $filtro): array;

    // Listar auditorías por ID de reserva
    public function listarPorReserva(int $reservaId): array;

    // Buscar auditoría por ID
    public function buscarPorId(int $idAudit): AuditoriaReservaResponse;
}
