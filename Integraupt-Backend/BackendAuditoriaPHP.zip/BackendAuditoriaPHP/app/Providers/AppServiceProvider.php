<?php

namespace App\Providers;

use App\Interfaces\IAuditoriaReservaServicio;
use App\Repositories\AuditoriaReservaRepository;
use App\Services\AuditoriaExportService;
use App\Services\AuditoriaReservaService;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    // Registrar los servicios de la aplicación
    public function register(): void
    {
        // Registrar el repositorio como singleton
        $this->app->singleton(AuditoriaReservaRepository::class, function ($app) {
            return new AuditoriaReservaRepository();
        });

        // Registrar la interfaz del servicio
        $this->app->singleton(IAuditoriaReservaServicio::class, function ($app) {
            return new AuditoriaReservaService(
                $app->make(AuditoriaReservaRepository::class)
            );
        });

        // Registrar el servicio de exportación
        $this->app->singleton(AuditoriaExportService::class, function ($app) {
            return new AuditoriaExportService(
                $app->make(IAuditoriaReservaServicio::class)
            );
        });
    }

    public function boot(): void
    {
        //
    }
}
