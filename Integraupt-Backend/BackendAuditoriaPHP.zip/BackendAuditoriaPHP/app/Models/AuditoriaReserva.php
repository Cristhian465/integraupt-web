<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Reserva;
use App\Models\Usuario;

class AuditoriaReserva extends Model
{
    // Nombre de la tabla
    protected $table = 'auditoriareserva';

    // Clave primaria
    protected $primaryKey = 'IdAudit';

    // No usar timestamps de Laravel
    public $timestamps = false;

    // Campos asignables
    protected $fillable = [
        'IdReserva',
        'EstadoAnterior',
        'EstadoNuevo',
        'UsuarioCambio',
    ];

    // Conversión de tipos
    protected $casts = [
        'IdAudit' => 'integer',
        'IdReserva' => 'integer',
        'FechaCambio' => 'datetime',
        'UsuarioCambio' => 'integer',
    ];

    // Relación con reserva
    public function reserva()
    {
        return $this->belongsTo(Reserva::class, 'IdReserva', 'IdReserva');
    }

    // Relación con usuario
    public function usuario()
    {
        return $this->belongsTo(Usuario::class, 'UsuarioCambio', 'IdUsuario');
    }
}
