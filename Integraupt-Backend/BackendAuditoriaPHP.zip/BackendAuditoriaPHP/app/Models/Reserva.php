<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Espacio;
use App\Models\AuditoriaReserva;

class Reserva extends Model
{
    protected $table = 'reserva';
    protected $primaryKey = 'IdReserva';
    public $timestamps = false;

    protected $casts = [
        'IdReserva' => 'integer',
        'fechaReserva' => 'date',
    ];

    // Relación con espacio
    public function espacio()
    {
        return $this->belongsTo(Espacio::class, 'espacio', 'IdEspacio');
    }

    // Auditorías de esta reserva
    public function auditorias()
    {
        return $this->hasMany(AuditoriaReserva::class, 'IdReserva', 'IdReserva');
    }
}
