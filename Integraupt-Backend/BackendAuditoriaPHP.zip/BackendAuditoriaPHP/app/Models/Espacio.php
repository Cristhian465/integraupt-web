<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Espacio extends Model
{
    protected $table = 'espacio';
    protected $primaryKey = 'IdEspacio';
    public $timestamps = false;

    protected $casts = [
        'IdEspacio' => 'integer',
    ];
}
