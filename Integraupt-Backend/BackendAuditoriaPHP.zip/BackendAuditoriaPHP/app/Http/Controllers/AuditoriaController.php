<?php

namespace App\Http\Controllers;

use App\DTOs\AuditoriaReservaFiltro;
use App\Interfaces\IAuditoriaReservaServicio;
use App\Services\AuditoriaExportService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

class AuditoriaController extends Controller
{
    private IAuditoriaReservaServicio $auditoriaReservaServicio;
    private AuditoriaExportService $auditoriaExportServicio;

    public function __construct(
        IAuditoriaReservaServicio $auditoriaReservaServicio,
        AuditoriaExportService $auditoriaExportServicio
    ) {
        $this->auditoriaReservaServicio = $auditoriaReservaServicio;
        $this->auditoriaExportServicio = $auditoriaExportServicio;
    }

    // Listar auditorías con filtros opcionales
    public function listar(Request $request): JsonResponse
    {
        $filtro = $this->construirFiltro($request);
        $resultados = $this->auditoriaReservaServicio->buscar($filtro);

        return response()->json(
            array_map(fn($r) => $r->toArray(), $resultados)
        );
    }

    // Obtener detalle de una auditoría
    public function detalle(int $id): JsonResponse
    {
        if ($id < 1) {
            throw new BadRequestHttpException('El ID debe ser mayor o igual a 1');
        }

        $resultado = $this->auditoriaReservaServicio->buscarPorId($id);

        return response()->json($resultado->toArray());
    }

    // Listar auditorías por ID de reserva
    public function porReserva(int $reservaId): JsonResponse
    {
        if ($reservaId < 1) {
            throw new BadRequestHttpException('El reservaId debe ser mayor o igual a 1');
        }

        $resultados = $this->auditoriaReservaServicio->listarPorReserva($reservaId);

        return response()->json(
            array_map(fn($r) => $r->toArray(), $resultados)
        );
    }

    // Exportar reporte en PDF
    public function exportarPdf(Request $request): Response
    {
        $filtro = $this->construirFiltro($request);
        $data = $this->auditoriaExportServicio->generarReportePdf($filtro);
        $filename = 'reporte_auditoria_' . time() . '.pdf';

        return response($data, 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ]);
    }

    // Exportar reporte en Excel
    public function exportarExcel(Request $request): Response
    {
        $filtro = $this->construirFiltro($request);
        $data = $this->auditoriaExportServicio->generarReporteExcel($filtro);
        $filename = 'reporte_auditoria_' . time() . '.xlsx';

        return response($data, 200, [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ]);
    }

    // Parsear fecha desde el request
    private function parseFecha(?string $valor, bool $endOfDay = false): ?string
    {
        if ($valor === null || trim($valor) === '') {
            return null;
        }

        try {
            // Si es solo fecha (YYYY-MM-DD, longitud 10)
            if (strlen($valor) === 10) {
                $fecha = new \DateTime($valor);
                if ($endOfDay) {
                    $fecha->setTime(23, 59, 59, 999999);
                } else {
                    $fecha->setTime(0, 0, 0);
                }
                return $fecha->format('Y-m-d H:i:s');
            }

            // Si es ISO DateTime (ej: 2025-11-11T15:30:00)
            $dateTime = new \DateTime($valor);
            return $dateTime->format('Y-m-d H:i:s');
        } catch (\Exception $e) {
            throw new BadRequestHttpException(
                'Formato de fecha no valido. Usa ISO-8601 (ej. 2025-11-11T15:30:00).'
            );
        }
    }

    // Construir filtro desde el request
    private function construirFiltro(Request $request): AuditoriaReservaFiltro
    {
        $reservaId = $request->query('reservaId');

        return new AuditoriaReservaFiltro(
            reservaId: $reservaId !== null ? (int) $reservaId : null,
            estado: $request->query('estado'),
            terminoUsuario: $request->query('usuario'),
            fechaInicio: $this->parseFecha($request->query('fechaInicio'), false),
            fechaFin: $this->parseFecha($request->query('fechaFin'), true),
        );
    }
}
