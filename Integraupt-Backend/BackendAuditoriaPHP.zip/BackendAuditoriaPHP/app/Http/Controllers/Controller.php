<?php

namespace App\Http\Controllers;

/**
 * Controlador base de Laravel.
 */
abstract class Controller
{
    //
}
