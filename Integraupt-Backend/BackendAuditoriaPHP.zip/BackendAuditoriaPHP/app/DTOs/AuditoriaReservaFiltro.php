<?php

namespace App\DTOs;

class AuditoriaReservaFiltro
{
    public function __construct(
        public readonly ?int $reservaId = null,
        public readonly ?string $estado = null,
        public readonly ?string $terminoUsuario = null,
        public readonly ?string $fechaInicio = null,
        public readonly ?string $fechaFin = null
    ) {}

    // Obtener estado (limpiando espacios)
    public function getEstado(): ?string
    {
        if ($this->estado === null) {
            return null;
        }
        $trimmed = trim($this->estado);
        return $trimmed === '' ? null : $trimmed;
    }

    // Obtener término de búsqueda de usuario (limpiando espacios)
    public function getTerminoUsuario(): ?string
    {
        if ($this->terminoUsuario === null) {
            return null;
        }
        $trimmed = trim($this->terminoUsuario);
        return $trimmed === '' ? null : $trimmed;
    }
}
