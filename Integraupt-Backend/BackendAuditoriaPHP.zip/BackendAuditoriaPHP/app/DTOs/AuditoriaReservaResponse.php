<?php

namespace App\DTOs;

class AuditoriaReservaResponse
{
    public function __construct(
        public readonly ?int $idAudit,
        public readonly ?int $idReserva,
        public readonly ?string $estadoAnterior,
        public readonly ?string $estadoNuevo,
        public readonly ?string $fechaCambio,
        public readonly ?int $usuarioCambioId,
        public readonly ?string $usuarioCambioNombre,
        public readonly ?string $usuarioCambioDocumento,
        public readonly ?string $estadoReservaActual,
        public readonly ?string $descripcionUso,
        public readonly ?string $fechaReserva,
        public readonly ?string $codigoEspacio,
        public readonly ?string $nombreEspacio
    ) {}

    // Convertir DTO a array para serialización JSON
    public function toArray(): array
    {
        return [
            'idAudit' => $this->idAudit,
            'idReserva' => $this->idReserva,
            'estadoAnterior' => $this->estadoAnterior,
            'estadoNuevo' => $this->estadoNuevo,
            'fechaCambio' => $this->fechaCambio,
            'usuarioCambioId' => $this->usuarioCambioId,
            'usuarioCambioNombre' => $this->usuarioCambioNombre,
            'usuarioCambioDocumento' => $this->usuarioCambioDocumento,
            'estadoReservaActual' => $this->estadoReservaActual,
            'descripcionUso' => $this->descripcionUso,
            'fechaReserva' => $this->fechaReserva,
            'codigoEspacio' => $this->codigoEspacio,
            'nombreEspacio' => $this->nombreEspacio,
        ];
    }
}
