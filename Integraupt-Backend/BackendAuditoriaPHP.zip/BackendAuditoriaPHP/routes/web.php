<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return response()->json([
        'servicio' => 'BackendAuditoriaPHP',
        'version' => '1.0.0',
        'descripcion' => 'Servicio REST para auditorías de reservas',
        'endpoints' => [
            'GET /api/auditorias' => 'Listar auditorías con filtros',
            'GET /api/auditorias/{id}' => 'Detalle de auditoría',
            'GET /api/auditorias/reserva/{reservaId}' => 'Auditorías por reserva',
            'GET /api/auditorias/exportacion/pdf' => 'Exportar PDF',
            'GET /api/auditorias/exportacion/excel' => 'Exportar Excel',
        ],
    ]);
});
