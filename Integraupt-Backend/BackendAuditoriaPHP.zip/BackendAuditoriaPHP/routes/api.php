<?php

use App\Http\Controllers\AuditoriaController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes - Auditoría de Reservas
|--------------------------------------------------------------------------
|
| Equivalente a @RequestMapping("/api/auditorias") del controlador Java.
|
| Todas las rutas tienen el prefijo /api (configurado por Laravel).
|
| Endpoints disponibles (mismos que el BackendAuditoria Java en puerto 8091):
|
| GET /api/auditorias                       -> Listar con filtros
| GET /api/auditorias/{id}                  -> Detalle por ID de auditoría
| GET /api/auditorias/reserva/{reservaId}   -> Listar por ID de reserva
| GET /api/auditorias/exportacion/pdf       -> Exportar PDF
| GET /api/auditorias/exportacion/excel     -> Exportar Excel
|
*/

Route::prefix('auditorias')->group(function () {

    // GET /api/auditorias
    // Params opcionales: reservaId, estado, usuario, fechaInicio, fechaFin
    Route::get('/', [AuditoriaController::class, 'listar']);

    // GET /api/auditorias/exportacion/pdf
    // Debe ir ANTES de /{id} para que no sea capturado como ID
    Route::get('/exportacion/pdf', [AuditoriaController::class, 'exportarPdf']);

    // GET /api/auditorias/exportacion/excel
    Route::get('/exportacion/excel', [AuditoriaController::class, 'exportarExcel']);

    // GET /api/auditorias/reserva/{reservaId}
    Route::get('/reserva/{reservaId}', [AuditoriaController::class, 'porReserva'])
        ->whereNumber('reservaId');

    // GET /api/auditorias/{id}
    Route::get('/{id}', [AuditoriaController::class, 'detalle'])
        ->whereNumber('id');

});
